import os
outCount=19
    
for count in range(16,17):

    src ="subtask_1_" + str(count) + ".txt"
    dst ='input'+str(outCount)+ ".txt" 
          
    # rename() function will 
    # rename all the files 
    os.rename(src, dst)

    outCount+=1
