import os
outCount=13
    
for count in range(26,30):
    src ="02-random-" + str(count)
    #src ="subtask_1_" + str(count) + ".txt"
    dst ='input'+str(count)+ ".txt" 
          
    # rename() function will 
    # rename all the files 
    os.rename(src, dst)

    outCount+=1
